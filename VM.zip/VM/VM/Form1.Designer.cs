﻿namespace VM
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.ColaPictureBox = new System.Windows.Forms.PictureBox();
            this.RBPictureBox = new System.Windows.Forms.PictureBox();
            this.LPictureBox = new System.Windows.Forms.PictureBox();
            this.GrapePictureBox = new System.Windows.Forms.PictureBox();
            this.CSPictureBox = new System.Windows.Forms.PictureBox();
            this.CPrice = new System.Windows.Forms.Label();
            this.RBPrice = new System.Windows.Forms.Label();
            this.LLPrice = new System.Windows.Forms.Label();
            this.GSPrice = new System.Windows.Forms.Label();
            this.CSPrice = new System.Windows.Forms.Label();
            this.CLabel = new System.Windows.Forms.Label();
            this.RBLabel = new System.Windows.Forms.Label();
            this.LLLabel = new System.Windows.Forms.Label();
            this.GSLabel = new System.Windows.Forms.Label();
            this.CSLabel = new System.Windows.Forms.Label();
            this.TLabel = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.ColaPictureBox)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.RBPictureBox)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.LPictureBox)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.GrapePictureBox)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.CSPictureBox)).BeginInit();
            this.SuspendLayout();
            // 
            // ColaPictureBox
            // 
            this.ColaPictureBox.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("ColaPictureBox.BackgroundImage")));
            this.ColaPictureBox.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ColaPictureBox.Location = new System.Drawing.Point(54, 12);
            this.ColaPictureBox.Name = "ColaPictureBox";
            this.ColaPictureBox.Size = new System.Drawing.Size(114, 109);
            this.ColaPictureBox.TabIndex = 0;
            this.ColaPictureBox.TabStop = false;
            this.ColaPictureBox.Click += new System.EventHandler(this.ColaPictureBox_Click);
            // 
            // RBPictureBox
            // 
            this.RBPictureBox.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("RBPictureBox.BackgroundImage")));
            this.RBPictureBox.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.RBPictureBox.Location = new System.Drawing.Point(303, 12);
            this.RBPictureBox.Name = "RBPictureBox";
            this.RBPictureBox.Size = new System.Drawing.Size(123, 109);
            this.RBPictureBox.TabIndex = 1;
            this.RBPictureBox.TabStop = false;
            this.RBPictureBox.Click += new System.EventHandler(this.RBPictureBox_Click);
            // 
            // LPictureBox
            // 
            this.LPictureBox.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("LPictureBox.BackgroundImage")));
            this.LPictureBox.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.LPictureBox.Location = new System.Drawing.Point(54, 165);
            this.LPictureBox.Name = "LPictureBox";
            this.LPictureBox.Size = new System.Drawing.Size(114, 107);
            this.LPictureBox.TabIndex = 2;
            this.LPictureBox.TabStop = false;
            this.LPictureBox.Click += new System.EventHandler(this.LPictureBox_Click);
            // 
            // GrapePictureBox
            // 
            this.GrapePictureBox.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("GrapePictureBox.BackgroundImage")));
            this.GrapePictureBox.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.GrapePictureBox.Location = new System.Drawing.Point(303, 165);
            this.GrapePictureBox.Name = "GrapePictureBox";
            this.GrapePictureBox.Size = new System.Drawing.Size(123, 107);
            this.GrapePictureBox.TabIndex = 3;
            this.GrapePictureBox.TabStop = false;
            this.GrapePictureBox.Click += new System.EventHandler(this.GrapePictureBox_Click);
            // 
            // CSPictureBox
            // 
            this.CSPictureBox.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("CSPictureBox.BackgroundImage")));
            this.CSPictureBox.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.CSPictureBox.Location = new System.Drawing.Point(54, 318);
            this.CSPictureBox.Name = "CSPictureBox";
            this.CSPictureBox.Size = new System.Drawing.Size(114, 96);
            this.CSPictureBox.TabIndex = 4;
            this.CSPictureBox.TabStop = false;
            this.CSPictureBox.Click += new System.EventHandler(this.CSPictureBox_Click);
            // 
            // CPrice
            // 
            this.CPrice.AutoSize = true;
            this.CPrice.Location = new System.Drawing.Point(183, 27);
            this.CPrice.Name = "CPrice";
            this.CPrice.Size = new System.Drawing.Size(49, 17);
            this.CPrice.TabIndex = 5;
            this.CPrice.Text = "CPrice";
            // 
            // RBPrice
            // 
            this.RBPrice.AutoSize = true;
            this.RBPrice.Location = new System.Drawing.Point(466, 27);
            this.RBPrice.Name = "RBPrice";
            this.RBPrice.Size = new System.Drawing.Size(59, 17);
            this.RBPrice.TabIndex = 6;
            this.RBPrice.Text = "RBPrice";
            // 
            // LLPrice
            // 
            this.LLPrice.AutoSize = true;
            this.LLPrice.Location = new System.Drawing.Point(186, 175);
            this.LLPrice.Name = "LLPrice";
            this.LLPrice.Size = new System.Drawing.Size(56, 17);
            this.LLPrice.TabIndex = 7;
            this.LLPrice.Text = "LLPrice";
            // 
            // GSPrice
            // 
            this.GSPrice.AutoSize = true;
            this.GSPrice.Location = new System.Drawing.Point(466, 175);
            this.GSPrice.Name = "GSPrice";
            this.GSPrice.Size = new System.Drawing.Size(60, 17);
            this.GSPrice.TabIndex = 8;
            this.GSPrice.Text = "GSPrice";
            // 
            // CSPrice
            // 
            this.CSPrice.AutoSize = true;
            this.CSPrice.Location = new System.Drawing.Point(186, 318);
            this.CSPrice.Name = "CSPrice";
            this.CSPrice.Size = new System.Drawing.Size(58, 17);
            this.CSPrice.TabIndex = 9;
            this.CSPrice.Text = "CSPrice";
            // 
            // CLabel
            // 
            this.CLabel.AutoSize = true;
            this.CLabel.Location = new System.Drawing.Point(183, 81);
            this.CLabel.Name = "CLabel";
            this.CLabel.Size = new System.Drawing.Size(52, 17);
            this.CLabel.TabIndex = 10;
            this.CLabel.Text = "CLabel";
            // 
            // RBLabel
            // 
            this.RBLabel.AutoSize = true;
            this.RBLabel.Location = new System.Drawing.Point(466, 81);
            this.RBLabel.Name = "RBLabel";
            this.RBLabel.Size = new System.Drawing.Size(62, 17);
            this.RBLabel.TabIndex = 11;
            this.RBLabel.Text = "RBLabel";
            // 
            // LLLabel
            // 
            this.LLLabel.AutoSize = true;
            this.LLLabel.Location = new System.Drawing.Point(186, 240);
            this.LLLabel.Name = "LLLabel";
            this.LLLabel.Size = new System.Drawing.Size(59, 17);
            this.LLLabel.TabIndex = 12;
            this.LLLabel.Text = "LLLabel";
            // 
            // GSLabel
            // 
            this.GSLabel.AutoSize = true;
            this.GSLabel.Location = new System.Drawing.Point(466, 240);
            this.GSLabel.Name = "GSLabel";
            this.GSLabel.Size = new System.Drawing.Size(63, 17);
            this.GSLabel.TabIndex = 13;
            this.GSLabel.Text = "GSLabel";
            // 
            // CSLabel
            // 
            this.CSLabel.AutoSize = true;
            this.CSLabel.Location = new System.Drawing.Point(183, 379);
            this.CSLabel.Name = "CSLabel";
            this.CSLabel.Size = new System.Drawing.Size(61, 17);
            this.CSLabel.TabIndex = 14;
            this.CSLabel.Text = "CSLabel";
            // 
            // TLabel
            // 
            this.TLabel.AutoSize = true;
            this.TLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TLabel.Location = new System.Drawing.Point(436, 341);
            this.TLabel.Name = "TLabel";
            this.TLabel.Size = new System.Drawing.Size(89, 29);
            this.TLabel.TabIndex = 15;
            this.TLabel.Text = "TLabel";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.TLabel);
            this.Controls.Add(this.CSLabel);
            this.Controls.Add(this.GSLabel);
            this.Controls.Add(this.LLLabel);
            this.Controls.Add(this.RBLabel);
            this.Controls.Add(this.CLabel);
            this.Controls.Add(this.CSPrice);
            this.Controls.Add(this.GSPrice);
            this.Controls.Add(this.LLPrice);
            this.Controls.Add(this.RBPrice);
            this.Controls.Add(this.CPrice);
            this.Controls.Add(this.CSPictureBox);
            this.Controls.Add(this.GrapePictureBox);
            this.Controls.Add(this.LPictureBox);
            this.Controls.Add(this.RBPictureBox);
            this.Controls.Add(this.ColaPictureBox);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            ((System.ComponentModel.ISupportInitialize)(this.ColaPictureBox)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.RBPictureBox)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.LPictureBox)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.GrapePictureBox)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.CSPictureBox)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.PictureBox ColaPictureBox;
        private System.Windows.Forms.PictureBox RBPictureBox;
        private System.Windows.Forms.PictureBox LPictureBox;
        private System.Windows.Forms.PictureBox GrapePictureBox;
        private System.Windows.Forms.PictureBox CSPictureBox;
        private System.Windows.Forms.Label CPrice;
        private System.Windows.Forms.Label RBPrice;
        private System.Windows.Forms.Label LLPrice;
        private System.Windows.Forms.Label GSPrice;
        private System.Windows.Forms.Label CSPrice;
        private System.Windows.Forms.Label CLabel;
        private System.Windows.Forms.Label RBLabel;
        private System.Windows.Forms.Label LLLabel;
        private System.Windows.Forms.Label GSLabel;
        private System.Windows.Forms.Label CSLabel;
        private System.Windows.Forms.Label TLabel;
    }
}

