﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Email
{
    class PersonEntry
    {
        public string ContactName;
        public string ContactEmail;
        public string ContactPhone;

        public PersonEntry(string contactname, string contactemail, string contactphone)
        {
            ContactName = contactname;
            ContactEmail = contactemail;
            ContactPhone = contactphone;
        }
    }
}
