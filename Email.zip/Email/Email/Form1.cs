﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

namespace Email
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        List<PersonEntry> people = new List<PersonEntry>(); /*List for the contact info */

        private void Form1_Load(object sender, EventArgs e)
        {
            StreamReader File = new StreamReader("ContactInfo.txt"); /*Reads the contents of "ContactInfo" */

            string contactname = "";
            string contactemail = "";
            string contactphone = "";
            string v;
            int i;

            while ((v = File.ReadLine()) != null)
                {
                i = 0;
                char ending = '*'; /*Setting the delimiter to * */
                string[] row = v.Split(ending);

                foreach (var substring in row) /*Seperated into 3 parts, first being the name, then the Email, then the phone number */
                {
                    if (i==0)
                    {
                        contactname = substring;   
                    }
                    else if (i==1)
                    {
                        contactemail = substring;
                    }
                    else
                    {
                        contactphone = substring;
                    }
                    i = i + 1;
                }

                PersonEntry contact = new PersonEntry(contactname, contactemail, contactphone);
                people.Add(contact);
                NameListing.Items.Add(contactname);
            }

        }

        private void NameListing_SelectedIndexChanged(object sender, EventArgs e)
        { /*When they click a name it will open form2 which will show the name, email, and phone of which ever person they selected */
            int b = NameListing.SelectedIndex;
            Form2 Description = new Form2();

            Description.NameLabel.Text = people[b].ContactName.ToString();
            Description.EmailLabel.Text = people[b].ContactEmail.ToString();
            Description.NumberLabel.Text = people[b].ContactPhone.ToString();

            Description.Show();
        }
    }
}
