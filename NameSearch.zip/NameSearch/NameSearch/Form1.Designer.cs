﻿namespace NameSearch
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.BoyBox = new System.Windows.Forms.TextBox();
            this.GirlBox = new System.Windows.Forms.TextBox();
            this.Go = new System.Windows.Forms.Button();
            this.Exit = new System.Windows.Forms.Button();
            this.BoyOut = new System.Windows.Forms.TextBox();
            this.GirlOut = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.label1.Location = new System.Drawing.Point(116, 100);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(38, 20);
            this.label1.TabIndex = 0;
            this.label1.Text = "Boy";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.label2.Location = new System.Drawing.Point(116, 152);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(36, 20);
            this.label2.TabIndex = 1;
            this.label2.Text = "Girl";
            // 
            // BoyBox
            // 
            this.BoyBox.Location = new System.Drawing.Point(175, 100);
            this.BoyBox.Name = "BoyBox";
            this.BoyBox.Size = new System.Drawing.Size(100, 22);
            this.BoyBox.TabIndex = 2;
            // 
            // GirlBox
            // 
            this.GirlBox.Location = new System.Drawing.Point(175, 149);
            this.GirlBox.Name = "GirlBox";
            this.GirlBox.Size = new System.Drawing.Size(100, 22);
            this.GirlBox.TabIndex = 3;
            // 
            // Go
            // 
            this.Go.Location = new System.Drawing.Point(348, 100);
            this.Go.Name = "Go";
            this.Go.Size = new System.Drawing.Size(75, 23);
            this.Go.TabIndex = 4;
            this.Go.Text = "Go";
            this.Go.UseVisualStyleBackColor = true;
            this.Go.Click += new System.EventHandler(this.Go_Click);
            // 
            // Exit
            // 
            this.Exit.Location = new System.Drawing.Point(348, 148);
            this.Exit.Name = "Exit";
            this.Exit.Size = new System.Drawing.Size(75, 23);
            this.Exit.TabIndex = 5;
            this.Exit.Text = "Exit";
            this.Exit.UseVisualStyleBackColor = true;
            this.Exit.Click += new System.EventHandler(this.Exit_Click);
            // 
            // BoyOut
            // 
            this.BoyOut.Location = new System.Drawing.Point(175, 226);
            this.BoyOut.Name = "BoyOut";
            this.BoyOut.Size = new System.Drawing.Size(279, 22);
            this.BoyOut.TabIndex = 6;
            // 
            // GirlOut
            // 
            this.GirlOut.Location = new System.Drawing.Point(175, 274);
            this.GirlOut.Name = "GirlOut";
            this.GirlOut.Size = new System.Drawing.Size(279, 22);
            this.GirlOut.TabIndex = 7;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.GirlOut);
            this.Controls.Add(this.BoyOut);
            this.Controls.Add(this.Exit);
            this.Controls.Add(this.Go);
            this.Controls.Add(this.GirlBox);
            this.Controls.Add(this.BoyBox);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox BoyBox;
        private System.Windows.Forms.TextBox GirlBox;
        private System.Windows.Forms.Button Go;
        private System.Windows.Forms.Button Exit;
        private System.Windows.Forms.TextBox BoyOut;
        private System.Windows.Forms.TextBox GirlOut;
    }
}

