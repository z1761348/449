﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace VM
{
    struct Beverages
    {
        public string Name;
        public double Price;
        public int Amount;
        public double SubTotal;
    }
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        private void CTotal() /*Adding up all the beverages and puts it into the TLabel as the total price */
        {
            double t;
            t = S[C].SubTotal + S[RB].SubTotal + S[LL].SubTotal +
                S[GS].SubTotal + S[CS].SubTotal;
            TLabel.Text = t.ToString("c");
        }

        private double CSTotal(double a, double p) /*Keeping track of the quantity (starting at 20 and going down from there) */
        {
            a = (20 - a) * p;
            return a;
        }
        private int BuyS(int a) 
        {
            if (a <= 0) /*If the vending machine doesn't have any left (0) */
            {
                MessageBox.Show("No More Available");
                return a;
            }

            else /*Otherwise proceed as normal and take one form the quantity */
            {
                a -= 1;
                return a;
            }
        }

        Beverages[] S = new Beverages[5];
        int C = 0;
        int RB = 1;
        int LL = 2;
        int GS = 3;
        int CS = 4;
        double Total = 0.00;


        private void Form1_Load(object sender, EventArgs e) /* When the form loads it sets the name, price and quantity for each beverage (all 5)*/
        {
            S[C].Name = "Cola";
            S[C].Price = 1.00;
            S[C].Amount = 20;
            S[C].SubTotal = 0.00;
            S[RB].Name = "Root Beer";
            S[RB].Price = 1.00;
            S[RB].Amount = 20;
            S[RB].SubTotal = 0.00;
            S[LL].Name = "Lemon Lime";
            S[LL].Price = 1.00;
            S[LL].Amount = 20;
            S[LL].SubTotal = 0.00;
            S[GS].Name = "Grape";
            S[GS].Price = 1.50;
            S[GS].Amount = 20;
            S[GS].SubTotal = 0.00;
            S[CS].Name = "Cream Soda";
            S[CS].Price = 1.50;
            S[CS].Amount = 20;
            S[CS].SubTotal = 0.00;

            CLabel.Text = S[C].Amount.ToString(); /*from here and below is connecting the labels/prices on the form to the set names above */
            CPrice.Text = S[C].Price.ToString("c");

            RBLabel.Text = S[RB].Amount.ToString();
            RBPrice.Text = S[RB].Price.ToString("c");

            LLLabel.Text = S[LL].Amount.ToString();
            LLPrice.Text = S[LL].Price.ToString("c");

            GSLabel.Text = S[GS].Amount.ToString();
            GSPrice.Text = S[GS].Price.ToString("c");

            CSLabel.Text = S[CS].Amount.ToString();
            CSPrice.Text = S[CS].Price.ToString("c");

            TLabel.Text = Total.ToString("c");
        }

        private void ColaPictureBox_Click(object sender, EventArgs e) /*This is the action when clicking the Cola Picture. Sets the price label and quantity and runs CTotal */
        {
            S[C].Amount = BuyS(S[C].Amount);
            CLabel.Text = S[C].Amount.ToString();

            S[C].SubTotal = CSTotal(S[C].Amount, S[C].Price);

            CTotal();
        }

        private void RBPictureBox_Click(object sender, EventArgs e) /*This is the action when clicking the Root Beer Picture. Sets the price label and quantity and runs CTotal */
        {
            S[RB].Amount = BuyS(S[RB].Amount);
            RBLabel.Text = S[RB].Amount.ToString();

            S[RB].SubTotal = CSTotal(S[RB].Amount, S[RB].Price);

            CTotal();
        }

        private void LPictureBox_Click(object sender, EventArgs e) /*This is the action when clicking the Lemon Lime Picture. Sets the price label and quantity and runs CTotal */
        {
            S[LL].Amount = BuyS(S[LL].Amount);
            LLLabel.Text = S[LL].Amount.ToString();

            S[LL].SubTotal = CSTotal(S[LL].Amount, S[LL].Price);

            CTotal();
        }

        private void GrapePictureBox_Click(object sender, EventArgs e) /*This is the action when clicking the Grape Soda Picture. Sets the price label and quantity and runs CTotal */
        {
            S[GS].Amount = BuyS(S[GS].Amount);
            GSLabel.Text = S[GS].Amount.ToString();

            S[GS].SubTotal = CSTotal(S[GS].Amount, S[GS].Price);

            CTotal();
        }

        private void CSPictureBox_Click(object sender, EventArgs e) /*This is the action when clicking the Crean Soda Picture. Sets the price label and quantity and runs CTotal */
        {
            S[CS].Amount = BuyS(S[CS].Amount);
            CSLabel.Text = S[CS].Amount.ToString();

            S[CS].SubTotal = CSTotal(S[CS].Amount, S[CS].Price);

            CTotal();
        }
    }
}
