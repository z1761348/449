﻿namespace BaseBall
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.ListB = new System.Windows.Forms.ListBox();
            this.SelectButton = new System.Windows.Forms.Button();
            this.Exit = new System.Windows.Forms.Button();
            this.InfoLabel = new System.Windows.Forms.Label();
            this.countBox = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // ListB
            // 
            this.ListB.FormattingEnabled = true;
            this.ListB.ItemHeight = 16;
            this.ListB.Location = new System.Drawing.Point(101, 34);
            this.ListB.Name = "ListB";
            this.ListB.Size = new System.Drawing.Size(178, 324);
            this.ListB.TabIndex = 0;
            // 
            // SelectButton
            // 
            this.SelectButton.Location = new System.Drawing.Point(347, 34);
            this.SelectButton.Name = "SelectButton";
            this.SelectButton.Size = new System.Drawing.Size(75, 23);
            this.SelectButton.TabIndex = 1;
            this.SelectButton.Text = "Select";
            this.SelectButton.UseVisualStyleBackColor = true;
            this.SelectButton.Click += new System.EventHandler(this.SelectButton_Click);
            // 
            // Exit
            // 
            this.Exit.Location = new System.Drawing.Point(490, 34);
            this.Exit.Name = "Exit";
            this.Exit.Size = new System.Drawing.Size(75, 23);
            this.Exit.TabIndex = 2;
            this.Exit.Text = "Exit";
            this.Exit.UseVisualStyleBackColor = true;
            this.Exit.Click += new System.EventHandler(this.Exit_Click);
            // 
            // InfoLabel
            // 
            this.InfoLabel.AutoSize = true;
            this.InfoLabel.Location = new System.Drawing.Point(344, 102);
            this.InfoLabel.Name = "InfoLabel";
            this.InfoLabel.Size = new System.Drawing.Size(392, 17);
            this.InfoLabel.TabIndex = 3;
            this.InfoLabel.Text = "Number of times the selected team has won the World Series";
            // 
            // countBox
            // 
            this.countBox.Location = new System.Drawing.Point(347, 136);
            this.countBox.Name = "countBox";
            this.countBox.Size = new System.Drawing.Size(100, 22);
            this.countBox.TabIndex = 4;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.countBox);
            this.Controls.Add(this.InfoLabel);
            this.Controls.Add(this.Exit);
            this.Controls.Add(this.SelectButton);
            this.Controls.Add(this.ListB);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ListBox ListB;
        private System.Windows.Forms.Button SelectButton;
        private System.Windows.Forms.Button Exit;
        private System.Windows.Forms.Label InfoLabel;
        private System.Windows.Forms.TextBox countBox;
    }
}

