﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

namespace BaseBall
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            StreamReader TeamFile = File.OpenText("Teams.txt");
            List<string> TeamList = new List<string>();

            while (!TeamFile.EndOfStream)
            {
                TeamList.Add(TeamFile.ReadLine());
                
            }
            foreach (string team in TeamList)
            {
                ListB.Items.Add(team);
            }
            TeamFile.Close();
        }

        private void SelectButton_Click(object sender, EventArgs e)
        {
            int wins = 0;

            StreamReader WinnerFile = File.OpenText("WorldSeriesWinners.txt");
            List<string> WinnerList = new List<string>();

            while (!WinnerFile.EndOfStream)
            {
                WinnerList.Add(WinnerFile.ReadLine());    
            }

            foreach (string Name in WinnerList)
            {
                if (Name == ListB.GetItemText(ListB.SelectedItem))
                    wins++;
            }

            countBox.Text = wins.ToString();
        }

        private void Exit_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
