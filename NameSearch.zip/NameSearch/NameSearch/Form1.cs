﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

namespace NameSearch
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Go_Click(object sender, EventArgs e)
        {
            StreamReader BoyFile = File.OpenText("BoyNames.txt"); /*Gets the Boy file */
            StreamReader GirlFile = File.OpenText("GirlNames.txt"); /*Gets the Girl file */

            List<string> NameList = new List<string>(); /*I will be putting all the names into NameList */

            while (!BoyFile.EndOfStream)
            {
                NameList.Add(BoyFile.ReadLine()); /* Adding the boys to NameList*/
                NameList.Add(GirlFile.ReadLine()); /*Adding the girls to NameList */
            }
            BoyFile.Close();
            GirlFile.Close();


            foreach (string Name in NameList)
            {
                if (NameList.Contains(BoyBox.Text)) /*Checks the Boy input to the Boy names */
                {
                    BoyOut.Text = BoyBox.Text + " is a popular name.";
                }
                else BoyOut.Text = BoyBox.Text + " is NOT a popular name."; /*If its not there it will go to this else statement */

                if (NameList.Contains(GirlBox.Text)) /* Checks the Boy input to the Boy names */
                {
                    GirlOut.Text = GirlBox.Text + " is a popular name.";
                }
                else GirlOut.Text = GirlBox.Text + " is NOT a popular name."; /*If its not there it will go to this else statement */
            }
        }

        private void Exit_Click(object sender, EventArgs e)
        {
            this.Close(); /*Closes the assignment */
        }
    }
}
